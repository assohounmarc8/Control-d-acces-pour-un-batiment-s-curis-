public class Carte {
    private String numeroCarte;
    private String code;

    // Constructeur
    public Carte(String numeroCarte, String code) {
        this.numeroCarte = numeroCarte;
        this.code = code;
    }

    // Getter pour le numéro de la carte
    public String getNumeroCarte() {
        return numeroCarte;
    }

    // Getter pour le code de la carte
    public String getCode() {
        return code;
    }

    // Setter pour modifier le code de la carte
    public void setCode(String code) {
        this.code = code;
    }
}
