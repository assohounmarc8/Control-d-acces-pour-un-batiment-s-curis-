import java.util.HashMap;
import java.util.Map;

public class AutomateAcces {
    public enum Etat {
        ATTENTE_CARTE, VERIFICATION_CODE, ACCES_ACCORDE, ACCES_REFUSE, ALARME
    }

    private Etat etatActuel;
    private boolean carteInseree;
    private String numeroCarteInseree;
    private int tentativesEchec;
    private Map<String, Carte> cartesEnMemoire;

    public AutomateAcces() {
        etatActuel = Etat.ATTENTE_CARTE;
        carteInseree = false;
        tentativesEchec = 0;
        cartesEnMemoire = new HashMap<>(); // Carte stockée en mémoire pendant l'exécution
    }

    // Ajouter une carte manuellement via le menu
    public void ajouterCarte(String numeroCarte, String code) {
        if (!cartesEnMemoire.containsKey(numeroCarte)) {
            cartesEnMemoire.put(numeroCarte, new Carte(numeroCarte, code));
            System.out.println("Carte ajoutée : " + numeroCarte);
        } else {
            System.out.println("La carte avec ce numéro existe déjà.");
        }
    }

    // Insérer une carte dans le système
    public void insererCarte(String numeroCarte) {
        if (!carteInseree) {
            if (cartesEnMemoire.containsKey(numeroCarte)) {
                carteInseree = true;
                numeroCarteInseree = numeroCarte;
                etatActuel = Etat.VERIFICATION_CODE;
                System.out.println("Carte insérée : " + numeroCarteInseree + ". Veuillez entrer votre code.");
            } else {
                System.out.println("Carte non trouvée dans la mémoire.");
            }
        } else {
            System.out.println("Une carte est déjà insérée.");
        }
    }

    // Vérifier le code de la carte insérée
    public void verifierCode(String codeSaisi) {
        if (etatActuel == Etat.VERIFICATION_CODE && carteInseree) {
            Carte carte = cartesEnMemoire.get(numeroCarteInseree);
            if (carte != null && carte.getCode().equals(codeSaisi)) {
                etatActuel = Etat.ACCES_ACCORDE;
                tentativesEchec = 0;
                System.out.println("Code correct. Accès accordé.");
            } else {
                tentativesEchec++;
                if (tentativesEchec >= 3) {
                    etatActuel = Etat.ALARME;
                    System.out.println("Trois tentatives incorrectes. Alarme déclenchée. L'accès est définitivement refusé.");
                } else {
                    etatActuel = Etat.ACCES_REFUSE;
                    System.out.println("Code incorrect. Accès refusé. Tentatives restantes : " + (3 - tentativesEchec));
                }
            }
        } else {
            System.out.println("Veuillez insérer une carte d'abord.");
        }
    }

    // Retirer la carte
    public void retirerCarte() {
        if (carteInseree) {
            carteInseree = false;
            etatActuel = Etat.ATTENTE_CARTE;
            tentativesEchec = 0;
            System.out.println("Carte retirée. Retour à l'attente.");
        } else {
            System.out.println("Aucune carte insérée.");
        }
    }

    public Etat getEtatActuel() {
        return etatActuel;
    }

    public boolean isCarteInseree() {
        return carteInseree;
    }

    public Map<String, Carte> getCartesEnMemoire() {
        return cartesEnMemoire;
    }
}
