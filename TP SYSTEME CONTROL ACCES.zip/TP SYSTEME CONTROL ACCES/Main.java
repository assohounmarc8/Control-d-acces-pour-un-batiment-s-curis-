import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AutomateAcces controleAcces = new AutomateAcces();
        boolean continuer = true;

        System.out.println("=== Système de Contrôle d'Accès ===");

        while (continuer) {
            System.out.println("\nÉtat actuel : " + controleAcces.getEtatActuel());
            System.out.println("Carte insérée : " + (controleAcces.isCarteInseree() ? "Oui" : "Non"));
            System.out.println("1. Ajouter une carte");
            System.out.println("2. Insérer une carte");
            System.out.println("3. Entrer un code correct");
            System.out.println("4. Retirer la carte");
            System.out.println("5. Quitter");
            System.out.print("Choisissez une option : ");

            int choix = scanner.nextInt();
            scanner.nextLine();  // Consommer le retour chariot après le choix

            switch (choix) {
                case 1:
                    // Ajouter une carte manuellement
                    System.out.print("Entrez le numéro de la carte : ");
                    String numeroCarte = scanner.nextLine();
                    System.out.print("Entrez le code de la carte : ");
                    String code = scanner.nextLine();
                    controleAcces.ajouterCarte(numeroCarte, code);
                    break;
                case 2:
                    // Insérer une carte
                    System.out.print("Entrez le numéro de la carte à insérer : ");
                    String numeroCarteInseree = scanner.nextLine();
                    controleAcces.insererCarte(numeroCarteInseree);
                    break;
                case 3:
                    // Vérifier un code correct
                    if (controleAcces.isCarteInseree()) {
                        System.out.print("Entrez le code pour la carte : ");
                        String codeSaisi = scanner.nextLine();
                        controleAcces.verifierCode(codeSaisi);
                    } else {
                        System.out.println("Veuillez insérer une carte d'abord.");
                    }
                    break;

                case 4:
                    // Retirer la carte
                    controleAcces.retirerCarte();
                    break;
                case 5:
                    // Quitter le programme
                    continuer = false;
                    System.out.println("Système arrêté. Merci d'avoir utilisé le système de contrôle d'accès.");
                    break;
                default:
                    System.out.println("Choix invalide. Veuillez réessayer.");
            }
        }

        scanner.close();
    }
}
